===================
License and Credits
===================

``pyRDF2Vec`` is licensed under the ``MIT`` license.  The full license text
can be also found in the `source code repository
<https://github.com/IBCNServices/pyRDF2Vec/blob/main/LICENSE>`_.

``pyRDF2Vec`` is written and maintained by `Gilles Vandewiele
<http://www.gillesvandewiele.com/>`_.

A full list of contributors can be found in `GitHub's overview
<https://github.com/IBCNServices/pyRDF2Vec/graphs/contributors>`_.
