pyrdf2vec.embedders.doc2vec module
==================================

.. automodule:: pyrdf2vec.embedders.doc2vec
   :members:
   :undoc-members:
   :show-inheritance:
