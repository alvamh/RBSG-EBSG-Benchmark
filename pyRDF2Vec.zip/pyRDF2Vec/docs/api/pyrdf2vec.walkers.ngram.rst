pyrdf2vec.walkers.ngram module
==============================

.. automodule:: pyrdf2vec.walkers.ngram
   :members:
   :undoc-members:
   :show-inheritance:
