pyrdf2vec.walkers.anonymous module
==================================

.. automodule:: pyrdf2vec.walkers.anonymous
   :members:
   :undoc-members:
   :show-inheritance:
