pyrdf2vec.walkers.walker module
===============================

.. automodule:: pyrdf2vec.walkers.walker
   :members:
   :undoc-members:
   :show-inheritance:
