pyrdf2vec.embedders.embedder module
===================================

.. automodule:: pyrdf2vec.embedders.embedder
   :members:
   :undoc-members:
   :show-inheritance:
