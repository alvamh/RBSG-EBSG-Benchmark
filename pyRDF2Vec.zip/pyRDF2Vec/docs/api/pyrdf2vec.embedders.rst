pyrdf2vec.embedders package
===========================

Submodules
----------

.. toctree::
   :maxdepth: 4

   pyrdf2vec.embedders.embedder
   pyrdf2vec.embedders.fasttext
   pyrdf2vec.embedders.word2vec

Module contents
---------------

.. automodule:: pyrdf2vec.embedders
   :members:
   :undoc-members:
   :show-inheritance:
