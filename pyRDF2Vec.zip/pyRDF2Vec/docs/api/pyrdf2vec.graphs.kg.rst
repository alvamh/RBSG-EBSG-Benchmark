pyrdf2vec.graphs.kg module
==========================

.. automodule:: pyrdf2vec.graphs.kg
   :members:
   :undoc-members:
   :show-inheritance:
