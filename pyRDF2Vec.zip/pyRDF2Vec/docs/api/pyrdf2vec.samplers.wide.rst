pyrdf2vec.samplers.wide module
==============================

.. automodule:: pyrdf2vec.samplers.wide
   :members:
   :undoc-members:
   :show-inheritance:
