pyrdf2vec.samplers.frequency module
===================================

.. automodule:: pyrdf2vec.samplers.frequency
   :members:
   :undoc-members:
   :show-inheritance:
