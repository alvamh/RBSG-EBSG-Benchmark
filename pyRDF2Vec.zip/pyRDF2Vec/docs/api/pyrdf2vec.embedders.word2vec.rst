pyrdf2vec.embedders.word2vec module
===================================

.. automodule:: pyrdf2vec.embedders.word2vec
   :members:
   :undoc-members:
   :show-inheritance:
