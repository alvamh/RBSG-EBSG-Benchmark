pyrdf2vec.walkers.weisfeiler\_lehman module
===========================================

.. automodule:: pyrdf2vec.walkers.weisfeiler_lehman
   :members:
   :undoc-members:
   :show-inheritance:
