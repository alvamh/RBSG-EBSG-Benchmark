pyrdf2vec.embedders.fasttext module
===================================

.. automodule:: pyrdf2vec.embedders.fasttext
   :members:
   :undoc-members:
   :show-inheritance:
