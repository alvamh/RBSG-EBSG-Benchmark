pyrdf2vec.graphs.vertex module
==============================

.. automodule:: pyrdf2vec.graphs.vertex
   :members:
   :undoc-members:
   :show-inheritance:
