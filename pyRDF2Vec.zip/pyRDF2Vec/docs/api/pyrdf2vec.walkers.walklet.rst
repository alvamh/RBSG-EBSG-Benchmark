pyrdf2vec.walkers.walklet module
================================

.. automodule:: pyrdf2vec.walkers.walklet
   :members:
   :undoc-members:
   :show-inheritance:
