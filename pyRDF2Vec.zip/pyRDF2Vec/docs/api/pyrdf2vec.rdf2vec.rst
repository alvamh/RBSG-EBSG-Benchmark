pyrdf2vec.rdf2vec module
========================

.. automodule:: pyrdf2vec.rdf2vec
   :members:
   :undoc-members:
   :show-inheritance:
