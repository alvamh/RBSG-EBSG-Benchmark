pyrdf2vec.typings module
========================

.. automodule:: pyrdf2vec.typings
   :members:
   :undoc-members:
   :show-inheritance:
