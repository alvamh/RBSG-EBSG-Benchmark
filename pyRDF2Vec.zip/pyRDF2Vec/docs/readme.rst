.. _readme:

.. include:: ../README.rst
   :start-after: rdf2vec-begin
   :end-before: getting-started-end
